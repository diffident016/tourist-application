package com.example.touristapplicationbyhighhopes;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class TouristSpotDetailActivity extends AppCompatActivity {

    private RecyclerView rvComments;
    private CommentAdapter commentAdapter;
    private List<CommentItem> commentItems;
    private EditText etUserComment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tourist_spot_detail);

        // Get data from intent
        Intent intent = getIntent();
        String spotName = intent.getStringExtra("spotName");
        int imageResourceId = intent.getIntExtra("imageResourceId", -1);

        // Initialize views
        ImageView ivTouristSpotImage = findViewById(R.id.ivTouristSpotImage);
        TextView tvTouristSpotDescription = findViewById(R.id.tvTouristSpotDescription);
        etUserComment = findViewById(R.id.etUserComment);
        Button btnComment = findViewById(R.id.btnComment);
        TextView tvCommentsTitle = findViewById(R.id.tvCommentsTitle);
        rvComments = findViewById(R.id.rvComments);

        // Set data to views
        ivTouristSpotImage.setImageResource(imageResourceId);
        tvTouristSpotDescription.setText(getDescriptionForSpot(spotName));

        // Initialize comments list and adapter
        commentItems = new ArrayList<>();
        commentAdapter = new CommentAdapter(commentItems);
        rvComments.setAdapter(commentAdapter);
        rvComments.setLayoutManager(new LinearLayoutManager(this));

        // Set click listener for comment button
        btnComment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addUserComment();
            }
        });
    }

    private String getDescriptionForSpot(String spotName) {
        // Implement this method to return the description based on the spot name
        switch (spotName) {
            case "Kaamulan Park":
                return "Kaamulan Park is a beautiful park located in Malaybalay City. It is known for its lush greenery and serene environment.";
            case "Monastery of Transfiguration":
                return "The Monastery of Transfiguration is a tranquil place of worship and reflection, located in the hills of Malaybalay.";
            case "Malaybalay city Plaza":
                return "Malaybalay City Plaza is a central public space where people gather for various events and activities.";
            case "Mt Capistrano":
                return "Mt Capistrano offers a challenging hike with rewarding views at the summit, perfect for adventure seekers.";
            default:
                return "Description not available.";
        }
    }

    private void addUserComment() {
        // Get the user's comment
        String userComment = etUserComment.getText().toString().trim();

        // Validate comment
        if (!userComment.isEmpty()) {
            // Add the comment to the list
            commentItems.add(new CommentItem("Anonymous", userComment));
            commentAdapter.notifyDataSetChanged();

            // Clear the input field
            etUserComment.setText("");

            // Show comments title if it's not visible
            if (commentItems.size() > 0) {
                findViewById(R.id.tvCommentsTitle).setVisibility(View.VISIBLE);
            }
        } else {
            // Optionally show a message if the comment is empty
            // Toast.makeText(this, "Please enter a comment", Toast.LENGTH_SHORT).show();
        }
    }
}
