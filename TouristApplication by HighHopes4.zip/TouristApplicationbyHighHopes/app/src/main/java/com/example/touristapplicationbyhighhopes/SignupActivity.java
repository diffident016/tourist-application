package com.example.touristapplicationbyhighhopes;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

public class SignupActivity extends AppCompatActivity {

    private EditText etSignupPassword;
    private ImageView ivShowHideSignupPassword;

    private boolean isPasswordVisible = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        etSignupPassword = findViewById(R.id.etSignupPassword);
        ivShowHideSignupPassword = findViewById(R.id.ivShowHideSignupPassword);

        // Set click listener on the eye icon to toggle password visibility
        ivShowHideSignupPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Toggle password visibility
                if (isPasswordVisible) {
                    // If password is currently visible, hide it
                    etSignupPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    ivShowHideSignupPassword.setImageResource(R.drawable.ic_eye_closed);
                } else {
                    // If password is currently hidden, show it
                    etSignupPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                    ivShowHideSignupPassword.setImageResource(R.drawable.ic_eye_open);
                }

                // Move cursor to the end of the text
                etSignupPassword.setSelection(etSignupPassword.getText().length());

                // Toggle the flag
                isPasswordVisible = !isPasswordVisible;
            }
        });

        // Initially, set password as hidden
        etSignupPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
    }
}

