package com.example.touristapplicationbyhighhopes;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.view.View;
import android.content.Intent;

public class TouristSpotDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tourist_spot_detail);

        // Get data from intent
        Intent intent = getIntent();
        String spotName = intent.getStringExtra("spotName");
        int imageResourceId = intent.getIntExtra("imageResourceId", -1);

        // Initialize views
        ImageView ivTouristSpotImage = findViewById(R.id.ivTouristSpotImage);
        TextView tvTouristSpotDescription = findViewById(R.id.tvTouristSpotDescription);
        Button btnComment = findViewById(R.id.btnComment);

        // Set data to views
        if (imageResourceId != -1) {
            ivTouristSpotImage.setImageResource(imageResourceId);
        }
        tvTouristSpotDescription.setText(getDescriptionForSpot(spotName));

        // Set click listener for comment button
        btnComment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent commentIntent = new Intent(TouristSpotDetailActivity.this, CommentActivity.class);
                startActivity(commentIntent);
            }
        });
    }

    private String getDescriptionForSpot(String spotName) {
        // Implement this method to return the description based on the spot name
        // For now, just return a placeholder description
        switch (spotName) {
            case "Kaamulan Park":
                return "Kaamulan Park is a beautiful park located in Malaybalay City. It is known for its lush greenery and serene environment.";
            case "Monastery of Transfiguration":
                return "The Monastery of Transfiguration is a tranquil place of worship and reflection, located in the hills of Malaybalay.";
            case "Malaybalay city Plaza":
                return "Malaybalay City Plaza is a central public space where people gather for various events and activities.";
            case "Mt Capistrano":
                return "Mt Capistrano offers a challenging hike with rewarding views at the summit, perfect for adventure seekers.";
            default:
                return "Description not available.";
        }
    }
}
