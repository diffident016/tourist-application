package com.example.touristapplicationbyhighhopes;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class TouristSpotDetailActivity extends AppCompatActivity {

    private TextView tvTouristSpotDescription;
    private Button btnAddComment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tourist_spot_detail);

        // Initialize views
        tvTouristSpotDescription = findViewById(R.id.tvTouristSpotDescription);
        btnAddComment = findViewById(R.id.btnAddComment);

        // Retrieve data passed from HomePageActivity
        String spotName = getIntent().getStringExtra("spotName");

        // Set description text based on spotName (dummy data for now)
        if (spotName != null && !spotName.isEmpty()) {
            String description = getTouristSpotDescription(spotName);
            tvTouristSpotDescription.setText(description);
        }

        // Set click listener for Add Comment button
        btnAddComment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle comment button click here
                // For now, you can add your logic to navigate or show comment dialog
                // Example:
                // startActivity(new Intent(TouristSpotDetailActivity.this, AddCommentActivity.class));
            }
        });
    }

    // Dummy method to retrieve description based on spotName
    private String getTouristSpotDescription(String spotName) {
        // You can implement your logic to fetch description based on spotName
        // For now, returning a dummy description
        if (spotName.equals("Kaamulan Park")) {
            return "Kaamulan Park is a famous tourist spot located in...";
        } else if (spotName.equals("Monastery of Transfiguration")) {
            return "Monastery of Transfiguration is a beautiful monastery situated in...";
        } else if (spotName.equals("Malaybalay city Plaza")) {
            return "Malaybalay City Plaza is a historic plaza known for...";
        } else if (spotName.equals("Mt Capistrano")) {
            return "Mt Capistrano is a breathtaking mountain peak offering stunning views...";
        } else {
            return "Description not available";
        }
    }
}
