package com.example.touristapplicationbyhighhopes;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private EditText etEmail, etPassword;
    private ImageView ivShowHidePassword;
    private Button btnLogin;
    private TextView tvSignup;
    private boolean isPasswordVisible = false;
    private MongoDBService mongoDBService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        ivShowHidePassword = findViewById(R.id.ivShowHidePassword);
        btnLogin = findViewById(R.id.btnLogin);
        tvSignup = findViewById(R.id.tvSignup);

        // Initialize MongoDBService
        mongoDBService = new MongoDBService();

        ivShowHidePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                togglePasswordVisibility();
            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = etEmail.getText().toString().trim();
                String password = etPassword.getText().toString().trim();

                if (email.isEmpty() || password.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter all fields", Toast.LENGTH_SHORT).show();
                } else {
                    // Check if user exists in MongoDB
                    authenticateUser(email, password);
                }
            }
        });

        tvSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Redirect to signup activity
                Intent intent = new Intent(MainActivity.this, SignupActivity.class);
                startActivity(intent);
            }
        });
    }

    private void togglePasswordVisibility() {
        if (isPasswordVisible) {
            // Hide Password
            etPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            ivShowHidePassword.setImageResource(R.drawable.ic_eye_closed);
        } else {
            // Show Password
            etPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
            ivShowHidePassword.setImageResource(R.drawable.ic_eye_open);
        }
        isPasswordVisible = !isPasswordVisible;
        // Move the cursor to the end of the text
        etPassword.setSelection(etPassword.getText().length());
    }

    private void authenticateUser(final String email, final String password) {
        // Execute AsyncTask to authenticate user in background
        new AsyncTask<Void, Void, Boolean>() {
            @Override
            protected Boolean doInBackground(Void... voids) {
                try {
                    // Query MongoDB to find user with matching email and password
                    return mongoDBService.authenticateUser(email, password);
                } catch (Exception e) {
                    Log.e(TAG, "Error authenticating user from MongoDB: " + e.getMessage());
                    return false;
                }
            }

            @Override
            protected void onPostExecute(Boolean isAuthenticated) {
                if (isAuthenticated) {
                    // Proceed to home page
                    Intent intent = new Intent(MainActivity.this, HomePageActivity.class);
                    startActivity(intent);
                    finish(); // Optional: Prevent going back to MainActivity on back press
                } else {
                    Toast.makeText(MainActivity.this, "Invalid email or password", Toast.LENGTH_SHORT).show();
                }
                // Close MongoDB client when done
                mongoDBService.close();
            }
        }.execute();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Ensure MongoDB client is closed when activity is destroyed
        if (mongoDBService != null) {
            mongoDBService.close();
        }
    }
}
