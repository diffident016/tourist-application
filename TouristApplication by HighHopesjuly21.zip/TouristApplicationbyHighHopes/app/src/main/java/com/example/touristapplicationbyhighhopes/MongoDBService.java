package com.example.touristapplicationbyhighhopes;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

public class MongoDBService {

    private static final String DATABASE_NAME = "touristapp";
    private static final String COLLECTION_NAME = "users"; // Name of the collection where users are stored

    // Marking these fields as final since they are initialized once and never change
    private final MongoClient mongoClient;
    private final MongoDatabase database;
    private final MongoCollection<Document> collection;

    public MongoDBService() {
        // Connect to MongoDB Atlas using a connection string from an environment variable
        String connectionString = System.getenv("MONGODB_CONNECTION_STRING");
        if (connectionString == null || connectionString.isEmpty()) {
            throw new IllegalStateException("MONGODB_CONNECTION_STRING environment variable is not set");
        }

        mongoClient = MongoClients.create(connectionString);

        // Access your database and collection
        database = mongoClient.getDatabase(DATABASE_NAME);
        collection = database.getCollection(COLLECTION_NAME);
    }

    // Method to insert a new user document into the 'users' collection
    public void insertUser(String username, String email, String password) {
        // Create a new document representing the user
        Document userDocument = new Document()
                .append("username", username)
                .append("email", email)
                .append("password", password);

        // Insert the document into the collection
        collection.insertOne(userDocument);
    }

    // Method to authenticate a user based on email and password
    public boolean authenticateUser(String email, String password) {
        Document query = new Document("email", email).append("password", password);
        Document user = collection.find(query).first();
        return user != null;
    }

    // Close the MongoDB client
    public void close() {
        mongoClient.close();
    }
}
