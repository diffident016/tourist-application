package com.example.touristapplicationbyhighhopes;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class SignupActivity extends AppCompatActivity {

    private EditText etSignupUsername, etSignupEmail, etSignupPassword;
    private ImageView ivShowHideSignupPassword;
    private Button btnSignup;
    private boolean isPasswordVisible = false;
    private MongoDBService mongoDBService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        etSignupUsername = findViewById(R.id.etSignupUsername);
        etSignupEmail = findViewById(R.id.etSignupEmail);
        etSignupPassword = findViewById(R.id.etSignupPassword);
        ivShowHideSignupPassword = findViewById(R.id.ivShowHideSignupPassword);
        btnSignup = findViewById(R.id.btnSignup);

        // Initialize MongoDBService
        mongoDBService = new MongoDBService();

        // Set click listener on the eye icon to toggle password visibility
        ivShowHideSignupPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                togglePasswordVisibility();
            }
        });

        // Set click listener on the signup button
        btnSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = etSignupUsername.getText().toString().trim();
                String email = etSignupEmail.getText().toString().trim();
                String password = etSignupPassword.getText().toString().trim();

                if (username.isEmpty() || email.isEmpty() || password.isEmpty()) {
                    Toast.makeText(SignupActivity.this, "Please enter all fields", Toast.LENGTH_SHORT).show();
                } else {
                    // Insert user into MongoDB
                    mongoDBService.insertUser(username, email, password);

                    // Redirect to MainActivity (login page)
                    Intent intent = new Intent(SignupActivity.this, MainActivity.class);
                    intent.putExtra("email", email); // Pass email to login page
                    startActivity(intent);
                    finish(); // Close SignupActivity to prevent going back on back press
                }
            }
        });

        // Initially, set password as hidden
        etSignupPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
    }

    private void togglePasswordVisibility() {
        if (isPasswordVisible) {
            // Hide Password
            etSignupPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            ivShowHideSignupPassword.setImageResource(R.drawable.ic_eye_closed);
        } else {
            // Show Password
            etSignupPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
            ivShowHideSignupPassword.setImageResource(R.drawable.ic_eye_open);
        }
        isPasswordVisible = !isPasswordVisible;
        // Move the cursor to the end of the text
        etSignupPassword.setSelection(etSignupPassword.getText().length());
    }
}
